from com.foodplaza.views.OrderView import OrderView, Orders

orderView = OrderView()
while True:
    print("1.place order\n2.show order by id\n3.show order by email\n4.show all order\n5.delete order\n6.change status")
    print("For exit enter any number(Note: except 1 to 6)")
    choice = int(input("enter your choice : "))
    if choice == 1:
        email = input('enter your emailId : ')
        mode = input('enter payment mode : ')
        flag = orderView.placeOrder(email, mode)
        print("order placed successfully!" if flag else "Something went wrong!!!")
    else:
        print("Thank you!!!")
        break
