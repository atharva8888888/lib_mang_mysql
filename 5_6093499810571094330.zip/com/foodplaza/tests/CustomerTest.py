from com.foodplaza.views.CustomerView import CustomerView
from com.foodplaza.models.Customer import Customer

customerView = CustomerView()
while True:
    print("1.register\n2.update\n3.profile\n4.delete account\n5.show all customer\n6.add cash")
    print("For exit enter any number(Note: except 1 to 6)")
    choice = int(input("enter your choice : "))
    if choice == 1:
        email = input('enter your emailId : ')
        name = input('enter your name : ')
        contact = int(input('enter your contact number : '))
        address = input('provide your address : ')
        password = input('enter strong password for login : ')
        customer = Customer(name,address,email,contact,password)
        flag = customerView.addCustomer(customer)
        print("customer added successfully!!!" if flag else "something went wrong!!!")
    elif choice == 2:
        email = input('enter your emailId : ')
        name = input('enter your name : ')
        contact = int(input('enter your contact number : '))
        address = input('provide your address : ')
        customer = Customer(name, address, email, contact)
        flag = customerView.updateCustomer(customer)
        print("customer updated successfully!!!" if flag else "something went wrong!!!")
    elif choice == 3:
        email = input('enter your emailId : ')
        customer = customerView.showCustomer(email)
        print(customer)
    elif choice == 4:
        pass
    elif choice == 5:
        print("Below is registered customer lists :")
        print("--------------------------------------------------------")
        data = customerView.showAllCustomer()
        for cust in data:
            print(cust)
        print("--------------------------------------------------------")
    elif choice == 6:
        email = input('enter your emailId : ')
        amt = int(input('enter amount : '))
        flag = customerView.addCash(email, amt)
        print("amount added successfully!" if flag else "Something went wrong!!!")
    else:
        print("Thank you for use...")
        break