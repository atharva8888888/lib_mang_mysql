from com.foodplaza.views.CartView import CartView, Cart

cartView = CartView()
while True:
    print("1.Add to cart\n2.Update cart\n3.show cart by id\n4.show my cart\n5.delete cart\n6.clear cart")
    print("For exit enter any number(Note: except 1 to 6)")
    choice = int(input('enter your choice : '))
    if choice == 1:
        fid = int(input('enter valid food-id : '))
        quant = int(input('provide quantity of food : '))
        email = input("provide email-id : ")
        cart = Cart()
        cart.setFoodId(fid)
        cart.setQuantity(quant)
        cart.setEmailId(email)
        flag = cartView.addCart(cart)
        print("cart added successfully!!!" if flag else "something went wrong!!!")
    elif choice == 2:
        cid = int(input("provide existing cart-id : "))
        quant = int(input('provide quantity of food : '))
        flag = cartView.updateCart(cid,quant)
        print("cart updated successfully!!!" if flag else "something went wrong!!!")
    else:
        print("Thank you!!!")
        break
