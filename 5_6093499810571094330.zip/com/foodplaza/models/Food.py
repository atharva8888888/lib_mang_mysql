class Food:
    def __init__(self, foodId=0, foodName=None, ftype='veg', category=None, price=0.0, image=None):
        self.__foodId = foodId
        self.__foodName = foodName
        self.__type = ftype
        self.__category = category
        self.__price = price
        self.__image = image

    def getFoodId(self):
        return self.__foodId

    def getFoodName(self):
        return self.__foodName

    def getType(self):
        return self.__type

    def getCategory(self):
        return self.__category

    def getPrice(self):
        return self.__price

    def getImage(self):
        return self.__image

    def setFoodId(self, foodId):
        self.__foodId = foodId

    def setFoodName(self, foodName):
        self.__foodName = foodName

    def setType(self, type):
        self.__type = type

    def setCategory(self, category):
        self.__category = category

    def setPrice(self, price):
        self.__price = price

    def setImage(self, image):
        self.__image = image

    def __str__(self) -> str:
        return f"Food[food-id: {self.__foodId}, food-name: {self.__foodName}, type: {self.__type}, " \
               f"category: {self.__category}, price: {self.__price}, image_path: {self.__image}]"
