class Orders:
    def __init__(self, Order_id=0, Cust_EmailId=None, Order_info=None, Status='placed', Total_bill=0.0, Payment_mode=None):
        self.__Order_id = Order_id
        self.__Cust_EmailId = Cust_EmailId
        self.__Order_info = Order_info
        self.__Status = Status
        self.__Total_bill = Total_bill
        self.__Payment_mode = Payment_mode

    def getOrder_id(self):
        return self.__Order_id

    def getCust_EmailId(self):
        return self.__Cust_EmailId

    def getOrder_info(self):
        return self.__Order_info

    def getStatus(self):
        return self.__Status

    def getTotal_bill(self):
        return self.__Total_bill

    def getPayment_mode(self):
        return self.__Payment_mode

    def setOrder_id(self, Order_id):
        self.__Order_id = Order_id

    def setCust_EmailId(self, Cust_EmailId):
        self.__Cust_EmailId = Cust_EmailId

    def setOrder_info(self, Order_info):
        self.__Order_info = Order_info

    def setStatus(self, Status):
        self.__Status = Status

    def setTotal_bill(self, Total_bill):
        self.__Total_bill = Total_bill

    def setPayment_mode(self, Payment_mode):
        self.__Payment_mode = Payment_mode
