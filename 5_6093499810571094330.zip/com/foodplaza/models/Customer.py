class Customer:
    def __init__(self, custName=None, address=None, emailId=None,contactNo=0, custPassword=None, wallet=0.0):
        self.__custName = custName
        self.__address = address
        self.__emailId = emailId
        self.__contactNo = contactNo
        self.__custPassword = custPassword
        self.__wallet = wallet

    def getCustName(self):
        return self.__custName

    def getAddress(self):
        return self.__address

    def getEmailId(self):
        return self.__emailId

    def getContactNo(self):
        return self.__contactNo

    def getPassword(self):
        return self.__custPassword

    def getWallet(self):
        return self.__wallet

    def setCustName(self, Cust_name):
        self.__custName = Cust_name

    def setAddress(self, Cust_address):
        self.__address = Cust_address

    def setEmailId(self, Cust_EmailId):
        self.__emailId = Cust_EmailId

    def setContactNo(self, ContactNo):
        self.__contactNo = ContactNo

    def setWallet(self, Wallet):
        self.__wallet = Wallet

    def __str__(self):
        return f"Customer[emailId: {self.__emailId}, custName: {self.__custName}, contactNo: {self.__contactNo}, " \
               f"address: {self.__address}, wallet: {self.__wallet}, custPassword: {self.__custPassword}]"
