class Cart:
    def __init__(self, Food_id=0, Cart_id=0, Cart_EmailId=None, Quantity=1, Food_Price=0.0, Total_Price=0.0):
        self.__foodId = Food_id
        self.__cartId = Cart_id
        self.__emailId = Cart_EmailId
        self.__quantity = Quantity
        self.__price = Food_Price
        self.__totalPrice = Total_Price

    def getFoodId(self):
        return self.__foodId

    def getCartId(self):
        return self.__cartId

    def getEmailId(self):
        return self.__emailId

    def getQuantity(self):
        return self.__quantity

    def getPrice(self):
        return self.__price

    def getTotalPrice(self):
        return self.__totalPrice

    def setFoodId(self, Food_Id):
        self.__foodId = Food_Id

    def setCartId(self, Cart_id):
        self.__cartId = Cart_id

    def setEmailId(self, Cart_EmailId):
        self.__emailId = Cart_EmailId

    def setQuantity(self, Quantity):
        self.__quantity = Quantity

    def setPrice(self, price):
        self.__price = price

    def setTotalPrice(self, Total_Price):
        self.__totalPrice = Total_Price

    def __str__(self):
        return f"Cart[cartId]"
