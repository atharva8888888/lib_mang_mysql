import mysql.connector as mysql


class DButility:
    @staticmethod
    def getConnection():
        config = {
            "host": 'localhost',
            "user": 'root',
            "password": 'root',
            "database": 'FoodPlaza_PPS09_Ashok',
            "port": 3308
        }
        con = mysql.connect(**config)
        return con


# to check whether database connection is working or not
if __name__ == "__main__":
    con = DButility.getConnection()
    if con:
        print("connection established...")
    else:
        print("ERROR!!!")
