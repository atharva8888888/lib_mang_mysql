from com.foodplaza.views.ViewPlannings import Orders as abc
from com.foodplaza.models.Orders import Orders
from com.foodplaza.utility.DButility import DButility


class OrderView(abc):
    def placeOrder(self, emailId, payment):  # bool
        try:
            con = DButility.getConnection()
            cur = con.cursor()
            sql = f"SELECT SUM(totalPrice) FROM Cart WHERE emailId='{emailId}'"
            cur.execute(sql)
            result = cur.fetchone()
            if result:
                total_bill = result[0]
                if payment.lower() == 'wallet':
                    sql = f"SELECT wallet FROM Customer WHERE emailId='{emailId}'"
                    cur.execute(sql)
                    wallet_amt = cur.fetchone()[0]
                    if total_bill > wallet_amt:
                        return False
                    else:
                        sql = f"UPDATE Customer SET wallet={wallet_amt-total_bill} WHERE emailId='{emailId}'"
                        cur.execute(sql)
                sql = f"SELECT f.foodName,f.type,c.totalPrice FROM Food f JOIN Cart c ON f.foodId=c.foodId and emailId='{emailId}'"
                cur.execute(sql)
                result = cur.fetchall()
                order_info = ""
                if result:
                    for info in result:
                        order_info += f"Food({info[0]},{info[1]},{info[2]}), "
                    sql = "INSERT INTO Orders(emailId,orderInfo,totalBill,paymentMode) VALUES(%s,%s,%s,%s)"
                    value = (emailId, order_info, total_bill, payment)
                    cur.execute(sql, value)
                    con.commit()
                    return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")

    def showOrder(self, orderId):  # order_object
        pass

    def showMyOrders(self, emailId):  # list_object
        pass

    def showAllOrders(self):  # list_object
        pass

    def deleteOrder(self, orderId):  # bool
        pass

    def changeStatus(self, orderId, status):  # bool
        pass
