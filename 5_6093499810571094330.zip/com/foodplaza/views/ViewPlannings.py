from abc import ABC, abstractmethod


class Customer(ABC):
    @abstractmethod
    def addCustomer(self, customer):        # -> bool
        pass

    @abstractmethod
    def updateCustomer(self, customer):     # -> bool
        pass

    @abstractmethod
    def showCustomer(self, emailId):            # -> customer_obj
        pass

    @abstractmethod
    def deleteCustomer(self, emailId):          # -> bool
        pass

    @abstractmethod
    def showAllCustomer(self):                  # -> list_obj
        pass

    @abstractmethod
    def addCash(self, emailId, amount):         # bool
        pass


class Food(ABC):
    @abstractmethod
    def addFood(self, food):                    # -> bool
        pass

    @abstractmethod
    def updateFood(self, food):                 # -> bool
        pass

    @abstractmethod
    def deleteFood(self, foodId):               # -> bool
        pass

    @abstractmethod
    def showAllFood(self):                      # -> list_obj
        pass

    @abstractmethod
    def searchById(self, foodId):                 # -> food_obj
        pass

    @abstractmethod
    def searchByName(self, foodName):             # -> list_obj
        pass

    @abstractmethod
    def searchByCategory(self, category):         # -> list_obj
        pass

    @abstractmethod
    def searchByType(self, type):                 # -> list_obj
        pass

    @abstractmethod
    def searchByPrice(self, min_price, max_price):  # -> list_obj
        pass


class Cart(ABC):
    @abstractmethod
    def addCart(self, cart):                        # -> bool
        pass

    @abstractmethod
    def updateCart(self, cartId, quantity):         # -> bool
        pass

    @abstractmethod
    def deleteCart(self, cartId):                   # -> bool
        pass

    @abstractmethod
    def showMyCart(self, emailId):                  # -> list_obj
        pass

    @abstractmethod
    def showCart(self, cartId):                     # -> cart_obj
        pass

    @abstractmethod
    def clearCart(self, emailId):                   # -> bool
        pass


class Orders(ABC):
    @abstractmethod
    def placeOrder(self, emailId, payment):      # bool
        pass

    @abstractmethod
    def showOrder(self, orderId):       # order_object
        pass

    @abstractmethod
    def showMyOrders(self, emailId):        # list_object
        pass

    @abstractmethod
    def showAllOrders(self):       # list_object
        pass

    @abstractmethod
    def deleteOrder(self, orderId):       # bool
        pass

    @abstractmethod
    def changeStatus(self, orderId, status):    # bool
        pass


class Login(ABC):
    @abstractmethod
    def customerLogin(self, emailId, password):     # bool
        pass

    @abstractmethod
    def adminLogin(self, username, password):       # bool
        pass

    @abstractmethod
    def updateCustomerPassword(self, emailId, newPassword):     # bool
        pass

    @abstractmethod
    def updateAdminPassword(self, username, newPassword):     # bool
        pass
