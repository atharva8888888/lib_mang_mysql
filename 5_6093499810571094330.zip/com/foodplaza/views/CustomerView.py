from com.foodplaza.views.ViewPlannings import Customer as abc
from com.foodplaza.utility.DButility import DButility
from com.foodplaza.models.Customer import Customer


class CustomerView(abc):
    def addCustomer(self, customer):  # -> bool
        try:
            sql = '''INSERT INTO Customer(emailId,custName,contactNo,address,custPassword) VALUES(%s,%s,%s,%s,%s)'''
            value = (customer.getEmailId(), customer.getCustName(), customer.getContactNo(), customer.getAddress(),
                     customer.getPassword())
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql, value)
            con.commit()
            return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")

    def updateCustomer(self, customer):  # -> bool
        try:
            sql = "UPDATE Customer SET custName=%s,contactNo=%s,address=%s WHERE emailId=%s"
            value = (customer.getCustName(), customer.getContactNo(), customer.getAddress(), customer.getEmailId())
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql, value)
            con.commit()
            return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")

    def showCustomer(self, emailId):  # -> customer_obj
        try:
            sql = "SELECT emailId,custName,contactNo,address,custPassword,wallet FROM Customer WHERE emailId=%s"
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql, (emailId,))
            result = cur.fetchone()
            con.commit()
            if result:
                customer = Customer(result[1], result[3], result[0], result[2], result[4], result[5])
                return customer
            else:
                return None
        except Exception as e:
            print(f"Error : {e}")

    def deleteCustomer(self, emailId):  # -> bool
        try:
            sql = f"DELETE FROM Customer WHERE emailId='{emailId}'"
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql)
            con.commit()
            return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")

    def showAllCustomer(self):  # -> list_obj
        try:
            sql = "SELECT emailId,custName,contactNo,address,wallet FROM Customer"
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql)
            result = cur.fetchall()
            con.commit()
            if result:
                all_customer = []
                for row in range(len(result)):
                    customer = Customer()
                    customer.setEmailId(result[row][0])
                    customer.setCustName(result[row][1])
                    customer.setContactNo(result[row][2])
                    customer.setAddress(result[row][3])
                    customer.setWallet(result[row][4])
                    all_customer.append(customer)
                return all_customer
            else:
                return None
        except Exception as e:
            print(f"Error : {e}")

    def addCash(self, emailId, amount):
        try:
            sql = f"SELECT wallet FROM Customer WHERE emailId='{emailId}'"
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql)
            result = cur.fetchone()
            if result:
                sql = f"UPDATE Customer SET wallet={amount+result[0]} WHERE emailId='{emailId}'"
                cur.execute(sql)
                con.commit()
            return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")
