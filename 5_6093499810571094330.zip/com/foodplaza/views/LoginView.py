from ViewPlannings import Login as abc
from com.foodplaza.utility.DButility import DButility


class LoginView(abc):
    def customerLogin(self, emailId, password):  # bool
        try:
            sql = f"SELECT password FROM Customer WHERE emailId={emailId}"
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql)
            result = cur.fetchone()
            con.commit()
            """if result:
                return password == result[0]
            else:
                return False"""
            return password == result[0] if result else False
        except Exception as e:
            print(f"Error : {e}")

    def adminLogin(self, username, password):  # bool
        pass

    def updateCustomerPassword(self, emailId, newPassword):  # bool
        pass

    def updateAdminPassword(self, username, newPassword):  # bool
        pass
