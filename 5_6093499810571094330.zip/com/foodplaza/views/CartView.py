from com.foodplaza.views.ViewPlannings import Cart as abc
from com.foodplaza.models.Cart import Cart
from com.foodplaza.utility.DButility import DButility


class CartView(abc):
    def addCart(self, cart):  # -> bool
        # user input -> foodId, emailId, quantity
        try:
            sql = f"SELECT price FROM Food WHERE foodId={cart.getFoodId()}"
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql)
            result = cur.fetchone()
            con.commit()
            if result:
                fprice = result[0]
                t_price = fprice * cart.getQuantity()
                sql = "INSERT INTO Cart(foodId,emailId,price,quantity,totalPrice) VALUES(%s, %s, %s, %s, %s)"
                value = (cart.getFoodId(), cart.getEmailId(), fprice, cart.getQuantity(), t_price)
                cur.execute(sql, value)
                con.commit()
            return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")

    def updateCart(self, cartId, quantity):  # -> bool
        try:
            sql = f"SELECT price FROM Cart WHERE cartId={cartId}"
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql)
            result = cur.fetchone()
            if result:
                price = result[0]
                t_price = price * quantity
                sql = f"UPDATE Cart SET quantity={quantity},totalPrice={t_price} WHERE cartId={cartId}"
                cur.execute(sql)
                con.commit()
            return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")

    def deleteCart(self, cartId):  # -> bool
        pass

    def showMyCart(self, emailId):  # -> list_obj
        pass

    def showCart(self, cartId):  # -> cart_obj
        pass

    def clearCart(self, emailId):  # -> bool
        pass