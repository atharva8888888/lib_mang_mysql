from ViewPlannings import Food as abc
from com.foodplaza.utility.DButility import DButility
from com.foodplaza.models.Food import Food


class FoodView(abc):
    def addFood(self, food):  # -> bool
        try:
            sql = "INSERT INTO Food(foodName,price,type,category,image) VALUES(%s,%f,%s,%s,%s)"
            value = (food.getFoodName(), food.getPrice(), food.getType(), food.getCategory(), food.getImage())
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql, value)
            con.commit()
            return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")

    def updateFood(self, food):  # -> bool
        try:
            sql = "UPDATE Food SET foodName=%s,price=%f,type=%s,category=%s,image=%s WHERE foodId=%i"
            value = (food.getFoodName(), food.getPrice(), food.getType(), food.getCategory(),
                     food.getImage(), food.getFoodId())
            con = DButility.getConnection()
            cur = con.cursor()
            cur.execute(sql, value)
            con.commit()
            return cur.rowcount > 0
        except Exception as e:
            print(f"Error : {e}")

    def deleteFood(self, foodId):  # -> bool
        pass

    def showAllFood(self):  # -> list_obj
        pass

    def searchById(self, foodId):  # -> food_obj
        pass

    def searchByName(self, foodName):  # -> list_obj
        pass

    def searchByCategory(self, category):  # -> list_obj
        pass

    def searchByType(self, type):  # -> list_obj
        pass

    def searchByPrice(self, min_price, max_price):  # -> list_obj
        pass